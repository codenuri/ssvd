#include <iostream>
#include <thread>
#include <atomic>

// 아래 구조체는 멀티스레드를 고려하지 않고 설계된 구조체
struct Machine
{
	int data{ 0 };
	int count{ 0 }; 
};
Machine m;

void foo()
{
	for (int i = 0; i < 1'000'000; i++)
	{
		++m.count;
	}
}
int main()
{
	std::thread t1(foo), t2(foo), t3(foo);

	t1.join();
	t2.join();
	t3.join();

	std::cout << m.count << std::endl;
}

#include <atomic>
#include <memory>
#include <iostream>
#include <mutex>

template<typename T> struct node
{
    T data;
    node* next;
    node(T const& data_) : data(data_) {}
};

template<typename T>
class thread_safe_stack
{
public:
    node<T>* head = nullptr;
public:
    // 아래 코드가 전형적으로 list 에 앞에 넣는 코드 입니다.
    void push(const T& data)
    {
        node<T>* new_node = new node<T>(data);

        new_node->next = head;
        head = new_node;
    }
};

thread_safe_stack<int> s;


int main()
{
    s.push(10);
    s.push(20);
    s.push(30);

}


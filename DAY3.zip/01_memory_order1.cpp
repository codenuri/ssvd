﻿#include <atomic>

// 아래 코드의 문제점은 ?

int a = 0;
int b = 0;

void threadA()
{
    a = b + 1;
    b = 1;
}

// threadB
void threadB()
{
    if (b == 1)
    {
		// a == 1 임을 보장 할수 있을까 ?
		assert( a == 1 );
    }
}

int main()
{
}
//00_false_sharing1
#include <iostream>
#include <thread>
#include "chronometry.h"

constexpr int sz = 100000000;

unsigned long long n1 = 0;
unsigned long long n2 = 0;

void f1()
{
	for (int i = 0; i < sz; i++)
	{
		n1 += 1;
	}
	std::cout << "f1 result: " << n1 << std::endl;
}
void f2()
{
	for (int i = 0; i < sz; i++)
	{
		n2 += 1;
	}
	std::cout << "f2 result: " << n2 << std::endl;
}

void single_thread()
{
	n1 = 0;
	n2 = 0;

	f1();
	f2();
}
void multi_thread()
{
	n1 = 0;
	n2 = 0;

	std::jthread t1(f1);
	std::jthread t2(f2);
}
int main()
{
	chronometry(single_thread);
	chronometry(multi_thread);
}

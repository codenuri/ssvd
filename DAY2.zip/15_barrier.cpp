// latch2 번복사


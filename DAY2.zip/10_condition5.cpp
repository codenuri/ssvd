// 12_shared_lock 복사

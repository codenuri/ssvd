#include <iostream>
#include <thread>
#include <mutex>
#include <exception>

std::mutex m;

void foo()
{
	std::lock_guard<std::mutex> lg(m);
	std::cout << "using shared data" << std::endl;
}

int main()
{
	std::jthread t1(foo);
	std::jthread t2(foo);
}




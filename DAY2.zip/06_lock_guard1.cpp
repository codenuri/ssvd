#include <iostream>
#include <thread>
#include <mutex>
#include <exception>

std::mutex m;

void goo()
{
    m.lock();    
    std::cout << "using shared data" << std::endl;
    m.unlock();
}

void foo()
{
    goo();
}

int main()
{
    std::jthread t1(foo);
    std::jthread t2(foo);
}




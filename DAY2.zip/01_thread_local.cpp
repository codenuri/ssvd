#include <iostream>
#include <thread>
#include <string_view>

// 3의 배수를 차례대로 반환 하는 함수 만들기

int next3times()
{
	int n = 0;
	n = n + 3;
	return n;
}
void foo(std::string_view name)
{
	std::cout << name << " : " << next3times() << std::endl;
	std::cout << name << " : " << next3times() << std::endl;
	std::cout << name << " : " << next3times() << std::endl;
}

int main()
{
	foo("A");
}




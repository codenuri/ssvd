#include <iostream>
#include <atomic>
#include <thread>
#include <mutex>
#include <chrono>
using namespace std::literals;

std::mutex m;

void work()
{
	m.lock();
	std::cout << "start. using shared resource" << std::endl;
	std::cout << "end.   using shared resource" << std::endl;
	m.unlock();
}

int main()
{
	std::thread t1(work), t2(work);

	t1.join();
	t2.join();
}
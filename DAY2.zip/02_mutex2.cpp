#include <iostream>
#include <thread>
#include <chrono>
#include <mutex>
using namespace std::literals;


int share_data = 0;

void foo()
{
    share_data = 100;
}

int main()
{
    std::jthread t1(foo);
    std::jthread t2(foo);
}




#include <iostream>
#include <atomic>
#include <thread>

class spinlock
{
	std::atomic_flag flag; // = ATOMIC_FLAG_INIT;
public:
	void lock() { while (flag.test_and_set()); }
	void unlock() { flag.clear(); }
};
spinlock spin;

void work()
{
	std::cout << "start. using shared resource" << std::endl;
	std::cout << "end.   using shared resource" << std::endl;
}

int main()
{
	std::thread t1(work),t2(work);

	t1.join();
	t2.join();
}

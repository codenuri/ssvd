#include <iostream>
#include <mutex>
#include <thread>
#include <string>
#include <chrono>
#include <semaphore>
using namespace std::literals;

std::mutex m;

void Download(std::string name)
{
    m.lock();
    for (int i = 0; i < 100; i++)
    {
        std::cout << name;
        std::this_thread::sleep_for(30ms);
    }
    std::cout << "\n finish " << name << std::endl;
    m.unlock();
}
int main()
{
    std::jthread t1(Download, "1");
    std::jthread t2(Download, "2");
    std::jthread t3(Download, "3");
    std::jthread t4(Download, "4");
    std::jthread t5(Download, "5");
}
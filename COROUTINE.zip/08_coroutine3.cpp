#include <iostream>
#include <coroutine>
#include <utility>

class Task
{
public:
    struct promise_type
    {
        int value = 0;

        std::suspend_always yield_value(int v)
        {
            value = v;
            return {};
        }

        Task get_return_object() { return Task{ std::coroutine_handle<promise_type>::from_promise(*this) }; }
        std::suspend_always initial_suspend() noexcept { return {}; }
        std::suspend_always final_suspend()   noexcept { return {}; }
        void return_void() {}
        void unhandled_exception() {}
    };

    std::coroutine_handle<promise_type> coro;   // 멤버 데이터

    Task(std::coroutine_handle<promise_type> coro) : coro{ coro } {}    // 생성자
};

Task foo()
{
    std::cout << "foo #1\n";
    co_yield 1;

    std::cout << "foo #2\n";
    co_yield 2;
    
    std::cout << "foo #2\n";
}
  
int main()
{
    Task task = foo();

    task.coro.resume();	// foo #1    
    std::cout << "main: " << task.coro.promise().value << '\n'; // 1

    task.coro.resume();	// foo #2
    std::cout << "main: " << task.coro.promise().value << '\n'; // 2

    task.coro.resume();	// foo #3

    if (task.coro.done())
        task.coro.destroy();
}

#include <thread>
#include <iostream>
#include <chrono>
using namespace std::literals;

// 동기 함수
void foo(int a, int b) { std::this_thread::sleep_for(3s); }

// 비동기 함수 #1. 내부적으로 스레드 생성
void goo(int a, int b, void(*handler)())
{
	std::thread([handler]() {
		std::this_thread::sleep_for(3s);
		handler();
		}).detach();
}
// 비동기 함수 #2. 내부적으로 OS 제공하는 비동기 함수 사용
void hoo(int a, int b )
{
	// Windows OS 의 WriteFileEx()
	// 대부분 파일, N/W, Serial 등의 등의 HW 관련 I/O 작업
}
int main()
{
//	foo(1, 2);

	goo(1, 2, []() { std::cout << "complete async operation\n"; });
	std::cout << "continue main\n";

//	hoo(1, 2);

	//	coroutine();
	//	coroutine();

	getchar();
}
void coroutine()
{
	// ...
	// 여기서 호출자(main) 으로 돌아감
	// main 에서 다시 호출시 이후 문장 부터 실행
	// ...
}
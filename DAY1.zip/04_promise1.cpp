#include <iostream>
#include <thread>
#include <future>
#include <chrono>
using namespace std::literals;

void add(int a, int b)
{
	int s = a + b;
}
int main()
{
	std::thread t(add, 10, 20);

	t.join();
}




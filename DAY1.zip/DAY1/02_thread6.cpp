#include <iostream>
#include <thread>

// join(), exception 이야기

int main()
{
    std::thread t; 

    t.join();	

	// #1. try~catch

	// #2. check joinable() 
}

#include <iostream>
#include <thread>

// join_thread 

class scoped_thread 
{
	std::thread t;
public:
	scoped_thread(std::thread th) : t(std::move(th)) {} 

	~scoped_thread()
	{
		if ( t.joinable() )
			t.join();
	}
};


void foo(int a, int b)
{
	std::cout << "foo : " << a << ", " << b << std::endl;
}

int main()
{
    std::thread t1(&foo, 10, 20);
	t1.join();
}



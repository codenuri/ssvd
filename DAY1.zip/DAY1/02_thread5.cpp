#include <iostream>
#include <thread>
#include <windows.h>
#include <chrono>
using namespace std::literals;

// native_handle_type 이야기
// => 스레드 우선 순위

void foo()
{
    auto tid = std::this_thread::get_id(); 
}

int main()
{
    std::thread t(&foo);

    t.join();
}


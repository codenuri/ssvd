#include <thread>

// copy, move

void f1(std::thread t)   // 인자로 스레드를 받는 함수
{
    t.join(); 
}

std::thread f2()		// 반환 값으로 스레드 반환
{
    return std::thread(foo());
}

void foo() {}
void goo() {}

int main()
{
    std::thread t1(&foo);
    std::thread t2(&goo);

	// #1. swap 
	t1.swap(t2); 

	// #2. copy, move
	std::thread t3 = t1;
	std::thread t4 = std::move(t1); 
    
	
	// #3. 대입, 이동 대입
	std::thread t5;	

	t5 = t2; 
	t5 = std::thread(&foo); 



	// #4. 함수 인자와 반환 값
	f1(t2);
	f1(std::move(t2);
	f1(std::thread(foo));

	auto t6 = f2();

	t2.join();
    t4.join();
	t5.join();
    t6.join();
}


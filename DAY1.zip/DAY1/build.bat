cls

@echo [101mg++ %* -std=c++26 [0m
@g++ %* -IA:\\CMC_HEADER -std=c++26 -lstdc++exp -o gout.exe

@IF %ERRORLEVEL% EQU 0 (
    gout.exe
) 

@del *.exe
@echo:
g++ 소스이름.cpp -std=c++20
cl  소스이름.cpp /std:c++latest






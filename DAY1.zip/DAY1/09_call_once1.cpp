#include <iostream>
#include <thread>
#include <chrono>
#include <mutex>
using namespace std::literals;

void init(int a, double d)
{
    std::cout << "init" << std::endl;
    std::this_thread::sleep_for(2s);
}
void foo()
{
    std::cout << "start foo" << std::endl;
    init(10, 3.4);     // 초기화
    std::cout << "finish foo" << std::endl;
}
int main()
{
    std::thread t1(foo);
    t1.join();
}




#include <iostream>
#include <chrono>
#include <thread>
using namespace std::literals;

// std::this_thread::yield() 
// => 현재 스레드의 남은 실행 시간을 양보

void mysleep(std::chrono::microseconds us)
{
    auto target = std::chrono::high_resolution_clock::now() + us;

    while (std::chrono::high_resolution_clock::now() < target)
        std::this_thread::yield();
}

int main()
{
    mysleep(1s);
}
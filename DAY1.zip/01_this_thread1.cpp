#include <iostream>
#include <thread>

// std::this_thread namespace 안에 있는 4개의 함수
// 1. std::this_thread::get_id()
// 2. std::this_thread::sleep_for()
// 3. std::this_thread::sleep_until()
// 4. std::this_thread::yield()			


int main()
{
    std::cout << std::this_thread::get_id() << std::endl;

    std::thread::id tid1 = std::this_thread::get_id();

}